import React from 'react'

const home = () => {
  return (
    <div>Home</div>
  )
}

export default home;