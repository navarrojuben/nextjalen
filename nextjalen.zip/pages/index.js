import Portfolio from './portfolio';

export default function Home() {
  return <Portfolio />;
}
